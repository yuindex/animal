const envList = [{"envId":"cloud1-8ghautw7cbf2383e","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}